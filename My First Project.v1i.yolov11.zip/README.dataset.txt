# My First Project > 2025-03-02 3:25pm
https://universe.roboflow.com/archmod/my-first-project-ezimd

Provided by a Roboflow user
License: CC BY 4.0

